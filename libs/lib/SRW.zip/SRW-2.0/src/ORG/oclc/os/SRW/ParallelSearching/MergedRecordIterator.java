/*
   Copyright 2006 OCLC Online Computer Library Center, Inc.

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
 */
/*
 * RemoteRecordIterator.java
 *
 * Created on November 10, 2005, 3:17 PM
 */

package ORG.oclc.os.SRW.ParallelSearching;

//import ORG.oclc.ber.DataDir;
import ORG.oclc.os.SRW.QueryResult;
import ORG.oclc.os.SRW.Record;
import ORG.oclc.os.SRW.RecordIterator;
import java.util.NoSuchElementException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author levan
 */
public class MergedRecordIterator implements RecordIterator {
    static Log log=LogFactory.getLog(MergedRecordIterator.class);

//    boolean perhapsCachedResults;
    int numRecs;
    long postings, startPoint;
    MergedQueryResult result;
    RecordIterator ri=null;
    String schemaID;
    
    /** Creates a new instance of RemoteRecordIterator */
    public MergedRecordIterator(MergedQueryResult result, long startPoint,
      int numRecs, String schemaID) throws InstantiationException {
        this.result=result;
        this.startPoint=startPoint;
        this.numRecs=numRecs;
        this.schemaID=schemaID;
//        if(startPoint==1)
//            perhapsCachedResults=true;
//        else
//            perhapsCachedResults=false;
        postings=result.getNumberOfRecords();
    }

    public void close() {
    }
    
    public boolean hasNext() {
        if(startPoint<=postings)
            return true;
        return false;
    }

    public Object next() throws NoSuchElementException {
        return nextRecord();
    }

    public Record nextRecord() throws NoSuchElementException {
        if(ri!=null && ri.hasNext())
            return ri.nextRecord();

        long actualStartPoint=startPoint;
        QueryResult qr=null;
        for(int i=0; i<result.db.length; i++) {
            if(result.db[i].result.getNumberOfRecords()>=actualStartPoint) {
                qr=result.db[i].result;
                break;
            }
            actualStartPoint-=result.db[i].result.getNumberOfRecords();
        }
        if(qr!=null) {
            try {
                ri=qr.newRecordIterator(actualStartPoint, numRecs, schemaID);
            }
            catch(InstantiationException e) {
                log.error(e, e);
                throw new NoSuchElementException(e.getMessage());
            }
            return ri.nextRecord();
        }
        return null;
    }
    
    public void remove() throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }
}
