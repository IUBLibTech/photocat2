/*
   Copyright 2006 OCLC Online Computer Library Center, Inc.

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.

    LuceneQueryResult.java
    Created January 15, 2006, 2:11 PM
 */

package ORG.oclc.os.SRW.DSpaceLucene;

import ORG.oclc.os.SRW.QueryResult;
import ORG.oclc.os.SRW.RecordIterator;
import java.util.Iterator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dspace.content.Item;
import org.dspace.search.QueryResults;

/**
 *
 * @author levan
 */
public class LuceneQueryResult extends QueryResult {
    static Log log=LogFactory.getLog(LuceneQueryResult.class);

    Item[] resultItems;
    QueryResults result=null;
    String cqlQuery;

    public LuceneQueryResult() {
    }
    
    public LuceneQueryResult(QueryResults result, Item[] resultItems) {
        this.result=result;
        this.resultItems=resultItems;
    }

    public long getNumberOfRecords() {
        if(result==null) // probably just holding diagnostics
            return 0;
        return result.getHitCount();
    }

    public RecordIterator newRecordIterator(long startPoint, int numRecs, String schemaID)
      throws InstantiationException {
        if(result==null)
            throw new InstantiationException("No results created");
        return new LuceneRecordIterator(result, resultItems, startPoint);
    }
}
