/*
   Copyright 2006 OCLC Online Computer Library Center, Inc.

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
 */
/*
 * LuceneRecordIterator.java
 *
 * Created on January 15, 2006, 2:29 PM
 */

package ORG.oclc.os.SRW.DSpaceLucene;

import ORG.oclc.os.SRW.Record;
import ORG.oclc.os.SRW.RecordIterator;
import java.util.NoSuchElementException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dspace.content.DCValue;
import org.dspace.content.Item;
import org.dspace.search.QueryResults;



/**
 *
 * @author levan
 */
public class LuceneRecordIterator implements RecordIterator {
    static final Log log=LogFactory.getLog(LuceneRecordIterator.class);
    static String DCSchemaID="info:srw/schema/1/dc-v1.1";

    Item[] resultsItems;
    long startPoint;
    QueryResults result;
    String schemaID;

    /** Creates a new instance of PearsRecordIterator */
    public LuceneRecordIterator(QueryResults result, Item[] resultsItems, long startPoint)
      throws InstantiationException {
        this.result=result;
        this.resultsItems=resultsItems;
        this.startPoint=startPoint;
        this.schemaID=schemaID;
    }

    public void close() {
    }
    
    public boolean hasNext() {
        if(startPoint<result.getHitCount())
            return true;
        return false;
    }

     private String makeDCRecord(DCValue[] values) {
        DCValue      value;
        StringBuffer sb=new StringBuffer();
        sb.append("<srw_dc:dc xmlns:srw_dc=\""+DCSchemaID+"\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\">\n");
        for(int i=0; i<values.length; i++) {
            value=values[i];
            sb.append("    <dc:").append(value.element);
            if(value.qualifier!=null)
                sb.append(".").append(value.qualifier);
            sb.append(">").append(value.value);
            sb.append("</dc:").append(value.element);
            if(value.qualifier!=null)
                sb.append(".").append(value.qualifier);
            sb.append(">\n");
        }
        sb.append("</srw_dc:dc>\n");

        return sb.toString();
    }

    public Object next() throws NoSuchElementException {
        return nextRecord();
    }

    public Record nextRecord() throws NoSuchElementException {
        DCValue[]    values=resultsItems[(int)startPoint-1].getDC(Item.ANY, Item.ANY, Item.ANY);
        startPoint++;
        String stringRecord=makeDCRecord(values);
        return new Record(stringRecord, DCSchemaID);
    }
    
    public void remove() throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }
}
