/**
 * ExplainPort.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jun 14, 2005 (09:15:57 EDT) WSDL2Java emitter.
 */

package gov.loc.www.zing.srw.interfaces;

public interface ExplainPort extends java.rmi.Remote {
    public gov.loc.www.zing.srw.ExplainResponseType explainOperation(gov.loc.www.zing.srw.ExplainRequestType body) throws java.rmi.RemoteException;
}
